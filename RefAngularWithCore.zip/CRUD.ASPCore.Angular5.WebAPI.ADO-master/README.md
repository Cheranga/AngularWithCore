# CRUD.ASPCore.Angular5.WebAPI.ADO
In this article I am going to explain how to create a MVC web application in ASP.NET Core 2.0 withAngular 5. We will be creating a sample Employee Record Management system using Angular 5 at frontend, Web Api on backend and ADO.NET to fetch data from database. We will use Angular form with required field validations for the input fields to get data from the user.

We will be using Visual Studio 2017 (Version 15.3.5 or above) and SQL Server 2008.
# Read the full article at
http://ankitsharmablogs.com/crud-operations-asp-net-core-using-angular-5-ado-net/
